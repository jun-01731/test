jQuery (function(){
        
 $("h1").click(function(){
     
    $("p").fadeOut(); 
     
 } )
    
        
        
        
        
        });